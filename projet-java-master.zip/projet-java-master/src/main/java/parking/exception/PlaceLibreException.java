package parking.exception;

import java.lang.Exception;

public class PlaceLibreException extends Exception
{
	private static final long serialVersionUID = 1L;
	// Vide car ne fais pas grand chose de plus que exception...
}
