package parking.exception;

public class PasAssezDObservateurException extends Exception
{
	private static final long serialVersionUID = 1L;
}
