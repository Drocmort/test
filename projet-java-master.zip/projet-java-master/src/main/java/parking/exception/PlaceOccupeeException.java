package parking.exception;

import java.lang.Exception;

public class PlaceOccupeeException extends Exception
{
	private static final long serialVersionUID = 1L;
}
